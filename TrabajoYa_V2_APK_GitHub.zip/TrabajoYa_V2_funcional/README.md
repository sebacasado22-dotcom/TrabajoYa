# TrabajoYa V2 funcional

App móvil web + base preparada para Capacitor/Android, conectada a Supabase.

## Funciones
- Registro e inicio de sesión con Supabase Auth.
- Perfil trabajador/empresa.
- Búsqueda de ofertas activas.
- Publicación de ofertas para cuentas Empresa.
- Postulaciones.
- Trabajos guardados.
- Calculadora rápida de precio.
- Diseño responsive móvil.

## Supabase
Proyecto: Trabajo Ya (`ekhdgrqffmzfnofcwmyn`)
URL: `https://ekhdgrqffmzfnofcwmyn.supabase.co`

La app usa solamente la publishable key. No incluye service_role.

## Desarrollo
```bash
npm install
npm run dev
```

## Android
```bash
npm install
npm run android:add
npm run android:sync
npm run android:open
```

Después se configura el firmado y se genera el `.aab` para Google Play.


## Generar APK desde el celular

Este proyecto incluye un workflow de GitHub Actions que compila automáticamente un APK de prueba.

1. Subí este proyecto a un repositorio de GitHub.
2. En GitHub abrí **Actions** → **Build TrabajoYa APK** → **Run workflow**.
3. Cuando termine, abrí la ejecución y descargá el artefacto **TrabajoYa-debug-apk**.
4. Extraé el ZIP y abrí `app-debug.apk` en tu Motorola para instalarlo.

La compilación usa el `appId` `com.trabajoya.app` y la publishable key de Supabase; no se incluye ninguna service role key.
