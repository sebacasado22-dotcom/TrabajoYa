# TrabajoYa V2 - mejoras de empresa y navegación Android

Incluye:
- Perfil de empresa: accesos a “Mis ofertas publicadas” y “Postulaciones recibidas”.
- Vista de postulaciones por oferta con datos del perfil del postulante y mensaje enviado.
- Cambio del estado de postulación (recibida, en revisión, aceptada o rechazada).
- Ajuste de área segura inferior para evitar que la barra de navegación tape los botones Android.
- Configuración de Capacitor para Android.

## Compilación
El workflow de GitHub Actions de este proyecto instala dependencias, compila Vite y crea el APK debug con Capacitor.

## Nota sobre permisos de base de datos
La app solo puede mostrar postulaciones si las políticas RLS de Supabase permiten que el empleador lea las postulaciones correspondientes a sus propias ofertas y los perfiles necesarios. Si la pantalla muestra un error de permisos, hay que ajustar las políticas de `applications` y `profiles` en Supabase antes de considerar la función terminada.
