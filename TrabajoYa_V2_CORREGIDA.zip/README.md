# TrabajoYa V2 corregida

Versión preparada para Android/Capacitor y Supabase.

Cambios principales:
- conexión de Supabase con sesión persistente y renovación automática;
- diagnóstico previo de conectividad para evitar el mensaje genérico “Failed to fetch”;
- mensajes de error de red más claros;
- Capacitor configurado con HTTPS y hostname localhost;
- workflow de GitHub Actions sin caché npm que dependa de un lockfile inexistente;
- Java 21 y Node 20 para el build Android;
- permiso INTERNET asegurado durante la compilación.

Proyecto Supabase: https://ekhdgrqffmzfnofcwmyn.supabase.co
App ID: com.trabajoya.app
